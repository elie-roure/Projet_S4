# projetS3

On sait jamais, si vous ne savez plus comment vous y prendre avec les branches, voici quelques petites commandes !

Créer des branches :

git branch [nom_branche]

Changer de branche :

git checkout [nom_branche]

Push sur une branche :

git push origin [nom_branche]

Supprimer une branche : 

git branch -d [nom branche]
git branch -D [nom branche]
